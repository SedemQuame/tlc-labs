class Trader{

	//class members
	private	String holderName;
	private Account holderAccount;


	//constructors
	

	//getter and setters
	

	//methods
	public void addTrade(){
		
	}

}
